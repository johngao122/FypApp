package com.example.fypapp2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.ShowableListMenu;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.amazonaws.auth.AWSCognitoIdentityProvider;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.Callback;
import com.amazonaws.mobile.client.results.SignInResult;
import com.amazonaws.mobile.client.results.SignUpResult;
import com.amazonaws.mobile.client.results.UserCodeDeliveryDetails;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUser;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserPool;
import com.amazonaws.services.cognitoidentityprovider.model.AdminListUserAuthEventsRequest;
import com.amazonaws.services.cognitoidentityprovider.model.ListUsersRequest;
import com.amazonaws.services.cognitoidentityprovider.model.ListUsersResult;
import com.amazonaws.mobile.client.UserState;
import com.amazonaws.mobile.client.UserStateDetails;
import com.amazonaws.mobile.client.UserStateListener;

import java.util.HashMap;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    EditText Password,Email;
    Button Login,Register,QR;
    private View.OnClickListener loginListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            AWSMobileClient.getInstance().signIn(
                    Email.getText().toString(),
                    Password.getText().toString(),
                    null,
                    new Callback<SignInResult>() {
                        @Override
                        public void onResult(SignInResult result) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Log.d("Auth","Sign in callback state: " + result.getSignInState());
                                    switch(result.getSignInState()){
                                        case DONE:
                                            Toast.makeText(getApplicationContext(),"Sign in Done",Toast.LENGTH_LONG).show();
                                            Intent i = new Intent(getApplicationContext(),iotactivity.class);
                                            startActivity(i);
                                            break;
                                        case SMS_MFA:
                                            Toast.makeText(getApplicationContext(),"Please confirm sign in with sms",Toast.LENGTH_SHORT).show();
                                            break;
                                        case NEW_PASSWORD_REQUIRED:
                                            Toast.makeText(getApplicationContext(),"Please confirm sign in with new password",Toast.LENGTH_SHORT);
                                            break;
                                        default:
                                            Toast.makeText(getApplicationContext(),"Unsupported sign in confirmation:" + result.getSignInState(),Toast.LENGTH_SHORT).show();
                                            break;
                                    }
                                }
                            });
                        }

                        @Override
                        public void onError(Exception e) {
                            Log.e("Auth","Sign in error",e);
                        }
                    }
            );

        }
    };
    private View.OnClickListener registerlistener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {


            final Map<String, String> attributes = new HashMap<>();
            attributes.put("email", Email.getText().toString());
            AWSMobileClient.getInstance().signUp(
                    Email.getText().toString(),
                    Password.getText().toString()
                    , attributes, null, new Callback<SignUpResult>() {
                        @Override
                        public void onResult(final SignUpResult signUpResult) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Log.d("Auth", "Sign-up callback state: " + signUpResult.getConfirmationState());
                                    if (!signUpResult.getConfirmationState()) {
                                        final UserCodeDeliveryDetails details = signUpResult.getUserCodeDeliveryDetails();
                                        Toast.makeText(getApplicationContext(), "Confirm sign-up with: " + details.getDestination(), Toast.LENGTH_SHORT).show();
                                        Intent i = new Intent(getApplicationContext(),CodeActivity.class);
                                        i.putExtra("Username",Email.getText().toString());
                                        startActivity(i);
                                    } else {
                                        Toast.makeText(getApplicationContext(), "Sign-up done.", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        }

                        @Override
                        public void onError(Exception e) {
                            Log.e("Auth", "Sign-up error", e);
                            Toast.makeText(getApplicationContext(),"Incorrect Username or Password",Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    };
    private View.OnClickListener qrlistener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(MainActivity.this,QRcode.class));
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Password = findViewById(R.id.passwordTextBox);
        Email = findViewById(R.id.emailTextBox);
        Login = findViewById(R.id.loginButton);
        Register = findViewById(R.id.registerButton);
        Login.setOnClickListener(loginListener);
        Register.setOnClickListener(registerlistener);
        QR =  findViewById(R.id.qrcodeButton);
        QR.setOnClickListener(qrlistener);

        AWSMobileClient.getInstance().initialize(getApplicationContext(), new Callback<UserStateDetails>() {

                    @Override
                    public void onResult(UserStateDetails userStateDetails) {
                        Log.i("INIT", "onResult: " + userStateDetails.getUserState());
                    }

                    @Override
                    public void onError(Exception e) {
                        Log.e("INIT", "Initialization error.", e);
                    }
                }
        );

    }
}