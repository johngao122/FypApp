package com.example.fypapp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.Callback;
import com.amazonaws.mobile.client.results.SignUpResult;
import com.amazonaws.mobile.client.results.UserCodeDeliveryDetails;

public class CodeActivity extends AppCompatActivity {

    EditText Code;
    Button Submit;
    String Username;
    private View.OnClickListener listener1 = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            AWSMobileClient.getInstance().confirmSignUp(
                    Username,
                    Code.getText().toString(),
                    new Callback<SignUpResult>() {
                        @Override
                        public void onResult(SignUpResult result) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Log.d("Auth","Signup callback state: " + result.getConfirmationState());
                                    if (!result.getConfirmationState()){
                                        final UserCodeDeliveryDetails details = result.getUserCodeDeliveryDetails();
                                        Toast.makeText(getApplicationContext(),"Please enter sign up code again",Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(getApplicationContext(),"Sign up is done",Toast.LENGTH_LONG).show();
                                        Intent i = new Intent(getApplicationContext(),iotactivity.class);
                                        startActivity(i);
                                    }
                                }
                            });
                        }

                        @Override
                        public void onError(Exception e) {
                            Log.e("Auth","Confirm sign up error",e);
                        }
                    }
            );

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code);

        Code = findViewById(R.id.codeTextBox);
        Submit = findViewById(R.id.submitButton);
        Submit.setOnClickListener(listener1);
        Username = getIntent().getStringExtra("Username");
    }
}